<?php
// Ajusta estos datos según tu XAMPP
define('DB_HOST', 'localhost');
define('DB_NAME', 'sistema_trajes');
define('DB_USER', 'root');
define('DB_PASS', '');

// Para enlaces y recursos (ajusta si tu carpeta cambia)
define('BASE_URL', 'http://localhost/sistema_trajes/');
